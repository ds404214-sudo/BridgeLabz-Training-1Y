package Gla.BuiltInFunctionPracticeProblem.level2;

import java.util.*;

public class FibonacciGenerator {
    static void fib(int n) {
        int a = 0, b = 1;
        for (int i = 1; i <= n; i++) {
            System.out.print(a + " ");
            int c = a + b;
            a = b;
            b = c;
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        fib(sc.nextInt());
    }
}
